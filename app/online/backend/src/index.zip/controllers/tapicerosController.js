const {
  getDistinctTapiceros,
  getAllByTapicero,
  getTareasByTapicero: modelGetTareasByTapicero
} = require('../models/pedidoDetalleModel');

/**
 * Controlador para obtener tapiceros con pedidos.
 */
async function getTapiceros(req, res) {
  try {
    const rows = await getDistinctTapiceros();
    // Mapear tapicero_id nulo a 'unassigned'
    const ids = rows.map(r => (
      r.tapicero_id === null ? 'unassigned' : r.tapicero_id
    ));
    res.json({ status: 'success', data: ids });
  } catch (error) {
    console.error('Error al obtener tapiceros:', error);
    res.status(500).json({ status: 'error', error: 'Error al obtener tapiceros.' });
  }
}

/**
 * Controlador para obtener detalles de pedido por tapicero.
 */
async function getPedidosByTapicero(req, res) {
  try {
    let { tapiceroId } = req.params;
    // Ajustar tapicero sin asignar
    if (tapiceroId === 'unassigned') tapiceroId = null;
    const detalles = await getAllByTapicero(tapiceroId);
    res.json({ status: 'success', data: detalles });
  } catch (error) {
    console.error(`Error al obtener pedidos de tapicero ${req.params.tapiceroId}:`, error);
    res.status(500).json({ status: 'error', error: 'Error al obtener pedidos por tapicero.' });
  }
}
/**
 * Controlador para obtener tareas (detalles con última etapa) por tapicero.
 */
async function getTareasByTapicero(req, res) {
  try {
    let { tapiceroId } = req.params;
    if (tapiceroId === 'unassigned') tapiceroId = null;
    const tareas = await modelGetTareasByTapicero(tapiceroId);
    res.json({ status: 'success', data: tareas });
  } catch (error) {
    console.error(`Error al obtener tareas de tapicero ${req.params.tapiceroId}:`, error);
    res.status(500).json({ status: 'error', error: 'Error al obtener tareas por tapicero.' });
  }
}

module.exports = {
  getTapiceros,
  getPedidosByTapicero,
  getTareasByTapicero
};