const express = require('express');
const { authenticateToken } = require('../middlewares/auth');
const { getTapiceros, getPedidosByTapicero, getTareasByTapicero } = require('../controllers/tapicerosController');

/**
 * @openapi
 * tags:
 *   - name: Tapiceros
 *     description: Gestión de tapiceros y sus pedidos
 */
const router = express.Router();

/**
 * @openapi
 * /api/tapiceros:
 *   get:
 *     summary: Obtener lista de tapiceros con pedidos asignados.
 *     tags: [Tapiceros]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de IDs de tapiceros.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                 data:
 *                   type: array
 *                   items:
 *                     type: string
 */
router.get('/', authenticateToken, getTapiceros);

/**
 * @openapi
 * /api/tapiceros/{tapiceroId}/pedidos:
 *   get:
 *     summary: Obtener pedidos asignados a un tapicero.
 *     tags: [Tapiceros]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: tapiceroId
 *         schema:
 *           type: string
 *         required: true
 *         description: ID del tapicero o 'unassigned'.
 *     responses:
 *       200:
 *         description: Lista de detalles de pedido.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/PedidoDetalle'
 */
router.get('/:tapiceroId/pedidos', authenticateToken, getPedidosByTapicero);
/**
 * @openapi
 * /api/tapiceros/{tapiceroId}/tareas:
 *   get:
 *     summary: Obtener tareas (detalles con última etapa) para un tapicero
 *     tags: [Tapiceros]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: tapiceroId
 *         schema:
 *           type: string
 *         required: true
 *         description: ID del tapicero o 'unassigned'
 *     responses:
 *       200:
 *         description: Lista de detalles de pedido con su última etapa
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 */
router.get('/:tapiceroId/tareas', authenticateToken, getTareasByTapicero);

module.exports = router;